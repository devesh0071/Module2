package com.example.mptdemorv.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mptdemorv.dao.CustomerDAO;
import com.example.mptdemorv.dto.Customer;
import com.example.mptdemorv.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerDAO daoRef;

	@Override
	public List<Customer> findAll() {

		return daoRef.findAll();
	}

	@Override
	public Customer add(Customer customer) {
		
		return daoRef.add(customer);
	}

	@Override
	public Customer findById(int id) {
	
		return daoRef.findById(id);
	}
	
	
}
