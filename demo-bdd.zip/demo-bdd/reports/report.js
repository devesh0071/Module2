$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/AwesomeFeature.feature");
formatter.feature({
  "name": "AwesomeFeature",
  "description": "\tIn order to avoid silly mistakes\n\tAs a math idiot\n\tI want to be told the sum of two numbers",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Add two numbers",
  "description": "",
  "keyword": "Scenario"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "I have entered 50 into calculator",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefs.iHaveEnteredIntoCalculator(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I have entered 70 into calculator",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefs.iHaveEnteredIntoCalculator(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I press add",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefs.i_press_add()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the result should be 120 on the screen",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefs.the_result_should_be_on_the_screen(int)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("src/test/resources/WikiPages.feature");
formatter.feature({
  "name": "test wikipedia search",
  "description": "\tIn order to verify result on wikipedia\n\tAs an end user\n\tI want to enter a search string",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "Enter search term \u0027\u003csearchTerm\u003e\u0027",
  "keyword": "Given "
});
formatter.step({
  "name": "Do search",
  "keyword": "When "
});
formatter.step({
  "name": "Multiple results are shown for \u0027\u003cresult\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "searchTerm",
        "result"
      ]
    },
    {
      "cells": [
        "mercury",
        "Mercury may refer to:"
      ]
    },
    {
      "cells": [
        "max",
        "Max may refer to:"
      ]
    }
  ]
});
formatter.scenario({
  "name": "",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Enter search term \u0027mercury\u0027",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefsWiki.enter_search_term_mercury(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Do search",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefsWiki.do_search()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Multiple results are shown for \u0027Mercury may refer to:\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefsWiki.multiple_results_are_shown_for_Mercury_may_refer_to(String)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Enter search term \u0027max\u0027",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefsWiki.enter_search_term_mercury(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Do search",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefsWiki.do_search()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Multiple results are shown for \u0027Max may refer to:\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefsWiki.multiple_results_are_shown_for_Mercury_may_refer_to(String)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});