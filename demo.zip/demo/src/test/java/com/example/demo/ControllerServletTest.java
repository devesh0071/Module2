package com.example.demo;



import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.cg.ControllerServlet;
import com.cg.dao.CarDAO;
import com.cg.dto.CarDTO;

@RunWith(MockitoJUnitRunner.class)
public class ControllerServletTest {

	
	
		@Mock
		private CarDAO carDAORef;
		
		@Mock
		private HttpServletRequest request;
		
		@Mock
		private HttpServletResponse response;
		
		@InjectMocks
		private ControllerServlet myServlet;
		
		
	@Test
	public void testProcessRequest() throws ServletException,IOException {
		//fail("Not yet implemented");
		//SETUP
		//Stubbing behavor for mocked object using WHEN-THEN pattern
		Mockito.when(request.getParameter("action")).thenReturn("viewCarList");
		
		//Data Fixture
		List<CarDTO>cars=new LinkedList<>();
		CarDTO car=new CarDTO();
		car.setMake("Honda");
		car.setModel("City");
		car.setModelYear("2000");
		cars.add(car);
		cars.add(car);
		
		Mockito.when(carDAORef.findAll()).thenReturn(cars);
		
		//Execution
		myServlet.processRequest(request,response);
		
		//Verification
		Mockito.verify(request).getParameter("action");
		Mockito.verify(carDAORef).findAll();
		
		//Edit
				Mockito.when(request.getParameter("action")).thenReturn("editCar");
				Mockito.when(request.getParameter("id")).thenReturn("1");
			    Mockito.when(carDAORef.findById(1)).thenReturn(car);
			    myServlet.processRequest(request,response);
				/*Mockito.verify(request).getParameter("action");*/
				Mockito.verify(carDAORef).findAll();
		
	}
	
	

}
