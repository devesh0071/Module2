public class PathPages {

	//static String url = "file:///D:/training/0726-BDD-Central-Team/eclipse-workspace/Cucumber-Selenium-POM-Demo/scr/main/webapp/LoanApplicationPage.html";
	private String url="file:///D:/Users/DSINGH39/Desktop/Cucumber-Selenium-POM-Demo/scr/main/webapp/LoanApplicationPage.html";
	private String title = "Loan Application Page";
	
	
	
	public PathPages(String url, String title) {
		
		String webPageLocation="file:///"+System.getProperty("user.dir")+"/src/main/webapp/";
		this.url=webPageLocation+url;
		this.title = title;
	}

	public void goTo() {
		
		Browser.goTo(url);
	}

	public boolean isAt() {
		return Browser.title().equals(title);
	}

	
	
}
