package com.capgemini.practicedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticeDemoApplication.class, args);
	}

}
