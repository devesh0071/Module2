package com.capgemini.practicedemo.service;

import java.util.List;

import com.capgemini.practicedemo.dto.CarDTO;

public interface CarService {
	  public List<CarDTO> findAll(); 
	    public CarDTO findById(int id);
	    public CarDTO create(CarDTO car);
	    public CarDTO update(CarDTO car);
	    public CarDTO delete(int id);

}
