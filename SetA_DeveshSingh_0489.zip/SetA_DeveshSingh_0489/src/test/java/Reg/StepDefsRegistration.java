package Reg;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.LoginPageFactory;
import pageBean.RegistrationPageFactory;
import pom.Browser;

public class StepDefsRegistration {

	private RegistrationPageFactory factory;;
	private LoginPageFactory login;

	@Before
	public void setup() {
		Browser browser = new Browser();

		factory = new RegistrationPageFactory(browser);
		login = new LoginPageFactory(browser);
	}
	
	@Given("^User is on RegistrationForm\\.html$")
	public void user_is_on_RegistrationForm_html() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.goTo();
		login.getBrowser().driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@Then("^check the title of the registration page$")
	public void check_the_title_of_the_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertTrue(login.isAt());
		login.getBrowser().driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@Given("^User is on RegistrationForm\\.html page$")
	public void user_is_on_RegistrationForm_html_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertTrue(login.isAt());
		login.getBrowser().driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^User leaves UserId blank$")
	public void user_leaves_UserId_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.setPfuname("");
		Thread.sleep(1000);
	    
	}

	@When("^clicks the Submit button$")
	public void clicks_the_Submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		factory.setPfbutton();
	    
	}

	@Then("^display RegistrationId alert message$")
	public void display_RegistrationId_alert_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
		
	    
	}

	@When("^User enters invalid username$")
	public void user_enters_invalid_username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.setPfuname("ram1");
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
		Thread.sleep(1000);
	   
	}

	@When("^user leaves Password blank$")
	public void user_leaves_Password_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.setPfpwd("");
		Thread.sleep(1000);
	}

	@Then("^display RegistrationPwd alert message$")
	public void display_RegistrationPwd_alert_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
	   
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.setPfpwd("12345");
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
	}

	@When("^user leaves address blank$")
	public void user_leaves_address_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.setPfadd("");
		Thread.sleep(1000);
	}

	@Then("^display registrationAdd alert message$")
	public void display_registrationAdd_alert_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
	}

	@When("^user enters incorrect address$")
	public void user_enters_incorrect_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.setPfadd("XYZ");
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
		
	}

	@When("^user have not selected any country$")
	public void user_have_not_selected_any_country() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.setPfcountry("");
		Thread.sleep(1000);
		
	}

	@Then("^display registrationCountry alert message$")
	public void display_registrationCountry_alert_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
	}

	@When("^user has entered wrong zipcode$")
	public void user_has_entered_wrong_zipcode() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.setPfpwd("sdfgh");
	}

	@Then("^display registrationZip alert message$")
	public void display_registrationZip_alert_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
	}

	@When("^user have enterd wrong email$")
	public void user_have_enterd_wrong_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		factory.setPfemail("neel@.com");
		Thread.sleep(1000);
		factory.setPfbutton();
	}

	@Then("^display registrationEmail alert message$")
	public void display_registrationEmail_alert_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
	}

	@When("^user have not selected any$")
	public void user_have_not_selected_any() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.setPfGender("");
		Thread.sleep(1000);
	}

	@Then("^display registrationGender alert message$")
	public void display_registrationGender_alert_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("******" + alertMessage);
		assertTrue(alertMessage.length() > 0);
	}

	@When("^user enters all valid registration data$")
	public void user_enters_all_valid_registration_data() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		factory.setPfuname("Dsingh");
		Thread.sleep(1000);
		factory.setPfpwd("1234567");
		Thread.sleep(1000);
		factory.setPfemail("neel.p@gmail.com");
		Thread.sleep(1000);
		factory.setPfname("Devesh");
		Thread.sleep(1000);
		factory.setPfadd("Pune");
		Thread.sleep(1000);
		factory.setPfcoun("India");
		Thread.sleep(1000);
		factory.setPfzip("77777");
		Thread.sleep(1000);
		factory.setPfgen("male");
		Thread.sleep(1000);
		factory.setPfcoun("");
		Thread.sleep(1000);
		factory.setPfbutton();
	}

	@Then("^display Successfull Registration message$")
	public void display_Successfull_Registration_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String alertMessage = factory.getBrowser().driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println("Success" + alertMessage);
		assertTrue(alertMessage.length() > 0);
		
	}
	
	@After
	public void close() {
//		login.getBrowser().close();
		if(factory.getBrowser()!=null)
		factory.getBrowser().close();
	}

}
