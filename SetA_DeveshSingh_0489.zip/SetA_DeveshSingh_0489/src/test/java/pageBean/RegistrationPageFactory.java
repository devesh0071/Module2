package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import pom.Browser;
import pom.PathPages;

public class RegistrationPageFactory extends PathPages {
	WebDriver driver;
	// step 1 : identify elements
	@FindBy(name = "txtFN")
	@CacheLookup
	WebElement pfuname;
	
	@FindBy(name = "txtFN")
	@CacheLookup
	WebElement pfpwd;
	
	@FindBy(name = "txtFN")
	@CacheLookup
	WebElement pfname;
	
	@FindBy(name = "txtFN")
	@CacheLookup
	WebElement pfadd;
	
	@FindBy(how = How.NAME, using = "country")
	@CacheLookup
	WebElement pfcoun;
	
	@FindBy(name = "txtFN")
	@CacheLookup
	WebElement pfzip;
	
	@FindBy(how = How.NAME, using = "Email")
	@CacheLookup
	WebElement pfemail;

	@FindBy(how = How.NAME, using = "Gender")
	@CacheLookup
	WebElement pfgen;


	// using how class
	@FindBy(how = How.ID, using = "btnPayment")
	@CacheLookup
	WebElement pfbutton;


	

	public void setPfuname(String suname) {
		pfname.sendKeys(suname);
	}

	
	 public void setPfpwd(String spwd) {
		pfname.sendKeys(spwd);
	}

	 public void setPfname(String sname) {
			pfname.sendKeys(sname);
		}
	 
	 public void setPfadd(String sadd) {
			pfname.sendKeys(sadd);
		}
	 
	 public void setPfcoun(String scoun) {
			pfname.sendKeys(scoun);
		}
	 
	 public void setPfzip(String szip) {
			pfname.sendKeys(szip);
		}
	 
	 public void setPfgen(String sgen) {
			pfname.sendKeys(sgen);
		}
	 
	public void setPfbutton() {
		pfbutton.click();
	}


	public void setPfemail(String semail) {
		pfemail.sendKeys(semail);
	}


	// getters
	public WebElement getPfuname() {
		return pfuname;
	}

	public WebElement getPfpwd() {
		return pfpwd;
	}
	
	
	public WebElement getPfname() {
		return pfname;
	}
	
	public WebElement getPfbutton() {
		return pfbutton;
	}


	public WebElement getPfemail() {
		return pfemail;
	}

	public WebElement getPfzip() {
		return pfzip;
	}

	public WebElement getPfcoun() {
		return pfcoun;
	}
	
	public WebElement getPfgen() {
		return pfgen;
	}

	public WebElement getPfadd() {
		return pfadd;
	}
	private static String page = "RegistrationForm.html";
	private static String title = "Registration Form";

	// initiating Elements
	public RegistrationPageFactory(Browser browser) {
		super(page, title, browser);
		PageFactory.initElements(super.getBrowser().driver, this);
	}

	@Override
	public Browser getBrowser() {
		// TODO Auto-generated method stub
		return super.getBrowser();
	}

}
