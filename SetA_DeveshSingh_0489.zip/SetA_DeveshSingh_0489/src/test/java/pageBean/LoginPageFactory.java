package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import pom.Browser;
import pom.PathPages;

public class LoginPageFactory extends PathPages{

	WebDriver driver;
	
	@FindBy(name="userId")
	@CacheLookup
	WebElement pfuname;
	
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement pfpwd;
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement pfname;
	
	@FindBy(name="userAddress")
	@CacheLookup
	WebElement pfadd;
	
	@FindBy(name="userCountry")
	@CacheLookup
	WebElement pfcountry;
	
	@FindBy(name="userzip")
	@CacheLookup
	WebElement pfzip;
	
	@FindBy(name="useremail")
	@CacheLookup
	WebElement pfemail;
	

	@FindBy(name="usergen")
	@CacheLookup
	WebElement pfgen;
	
	
	@FindBy(how=How.CLASS_NAME, using="btn")
	@CacheLookup
	WebElement pfbutton;

	public WebElement getPfuname() {
		return pfuname;
	}

   public void setPfuname(String suname) {
		pfuname.sendKeys(suname);
	}


	public WebElement getPfpwd() {
		return pfpwd;
	}
	public void setPfpwd(String spwd) {
		pfpwd.sendKeys(spwd);
	}

	public WebElement getPfname() {
		return pfname;
	}

   public void setPfname(String sname) {
		pfuname.sendKeys(sname);
	}
   
	public void setPfadd(String sadd) {
		pfpwd.sendKeys(sadd);
	}
	
	public WebElement getPfadd() {
		return pfadd;
	}

	
	public void setPfcountry(String scoun) {
		pfpwd.sendKeys(scoun);
	}
	
	public WebElement getPfcontry() {
		return pfcountry;
	}

	public void setPfzip(String szip) {
		pfpwd.sendKeys(szip);
	}
	
	public WebElement getPfzip() {
		return pfzip;
	}

	public void setPfemail(String semail) {
		pfpwd.sendKeys(semail);
	}
	
	public WebElement getPfemail() {
		return pfemail;
	}

	
	public void setPfGender(String sgen) {
		pfpwd.sendKeys(sgen);
	}
	
	public WebElement getPfGender() {
		return pfgen;
	}

	
	
	public WebElement getPfbutton() {
		return pfbutton;
	}

	
	public void setPfbutton() {
	pfbutton.click();
	}

	private static String  page="login.html";
	private static String title = "login";
	
	//initiating Elements
		public LoginPageFactory(Browser browser) {
			super(page,title,browser);
			PageFactory.initElements(super.getBrowser().driver, this);
		}
}
