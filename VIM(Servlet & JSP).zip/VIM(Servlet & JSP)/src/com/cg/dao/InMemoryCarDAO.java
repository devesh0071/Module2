package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.dto.CarDTO;

public class InMemoryCarDAO implements CarDAO {
	Map<Integer, CarDTO> carmap = null;
static int count=1;
	public InMemoryCarDAO() {
		carmap = new HashMap<Integer, CarDTO>();
	}

	@Override
	public List<CarDTO> findAll() {
		List<CarDTO> cars = new ArrayList<CarDTO>(carmap.values());

		// TODO Auto-generated method stub
		return cars;
	}

	@Override
	public CarDTO findById(int id) {
		CarDTO cars1 = carmap.get(id);

		// TODO Auto-generated method stub
		return cars1;
	}

	@Override
	public void create(CarDTO car) {
		car.setId(count++);
		CarDTO car1 = carmap.putIfAbsent(car.getId(), car);

		// TODO Auto-generated method stub

	}

	@Override
	public void update(CarDTO car) {
		CarDTO car1 = carmap.put(car.getId(), car);
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(String[] ids) {
		count=1;
		for (String a : ids) {
			carmap.remove(Integer.parseInt(a));
		}
		// TODO Auto-generated method stub

	}

}
